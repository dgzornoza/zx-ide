#ifndef __Z88DK_HEADERS_H__
#define __Z88DK_HEADERS_H__

#define USE_NEW_LIB // (ZX-IDE) Not edit this line, is required by Zx-ide extension.

/**
 * This file is used to include the correct z88dk headers
 */

#ifdef USE_NEW_LIB
// add z88dk newlib include paths ...
#include <arch/zx.h>
#endif

#ifdef USE_CLASSIC_LIB
// add z88dk classic lib include paths ...
#include <arch/zx/spectrum.h>
#endif

#endif // __Z88DK_HEADERS_H__
