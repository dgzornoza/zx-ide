#ifndef __Z88DK_HEADERS_H__
#define __Z88DK_HEADERS_H__

// z88dk includes
{ZX-IDE_PROJECT_INCLUDES}

#endif // __Z88DK_HEADERS_H__
